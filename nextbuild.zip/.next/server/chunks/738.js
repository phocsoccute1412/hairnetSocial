exports.id = 738;
exports.ids = [738];
exports.modules = {

/***/ 9738:
/***/ ((module) => {

// Exports
module.exports = {
	"Logo": "homePage_Logo__rbiMx",
	"Header": "homePage_Header__6dfkO",
	"Men": "homePage_Men__Q9PMf",
	"Social": "homePage_Social__gNe4H",
	"Woman": "homePage_Woman__gc10p",
	"Hot": "homePage_Hot__n0mtJ",
	"loginHeader": "homePage_loginHeader__t2NQ5",
	"headerAvatar": "homePage_headerAvatar__70Q0m",
	"Carousel": "homePage_Carousel__OFTPr",
	"imageCarousel2": "homePage_imageCarousel2__wRYEr",
	"imageCarousel1": "homePage_imageCarousel1__3S0xq",
	"titleBotHeader": "homePage_titleBotHeader____FG8",
	"khungCarousel": "homePage_khungCarousel__lM9VY",
	"CarouselImage": "homePage_CarouselImage__zn5_a",
	"CarouselIndicator": "homePage_CarouselIndicator__XveTL",
	"Pic2": "homePage_Pic2__llQR0",
	"Pic3": "homePage_Pic3__68CeH",
	"ImageActive": "homePage_ImageActive__iOs3L",
	"buttonCarousel": "homePage_buttonCarousel__iXHMW",
	"nutphai": "homePage_nutphai__C0GY0",
	"buttonCarouselLeft": "homePage_buttonCarouselLeft__XJtAb",
	"nuttrai": "homePage_nuttrai__5fnu_",
	"signuptext": "homePage_signuptext__0Xoep",
	"record": "homePage_record__tZgMF",
	"blank1": "homePage_blank1__3AKMo",
	"blank2": "homePage_blank2__7K0bS",
	"blank3": "homePage_blank3__s_6oO",
	"buttonSignup": "homePage_buttonSignup__KYfvl",
	"otherSignUpText": "homePage_otherSignUpText__ZPEnl",
	"footer": "homePage_footer__DbRei",
	"titleFooter": "homePage_titleFooter__VhLym",
	"contact": "homePage_contact__8V_QU",
	"loginTitle": "homePage_loginTitle__rPMpx",
	"part": "homePage_part__NeT5H",
	"formLoginPersonalPage": "homePage_formLoginPersonalPage__2mAH0",
	"inputPart1": "homePage_inputPart1__i2kNr",
	"inputPart2": "homePage_inputPart2__O8iyH",
	"footerPart": "homePage_footerPart__9THbN",
	"loginButton": "homePage_loginButton__G_6zZ",
	"textVisit": "homePage_textVisit__iPYKw",
	"containerVisit": "homePage_containerVisit__0R4H_",
	"dropdownHeader": "homePage_dropdownHeader__WVK__",
	"dropdownHeaderActive": "homePage_dropdownHeaderActive__RUpzb",
	"HotPart": "homePage_HotPart__JY0wm",
	"personalSetting": "homePage_personalSetting__2LKYz",
	"personalSettingActive": "homePage_personalSettingActive__5yjWz"
};


/***/ })

};
;