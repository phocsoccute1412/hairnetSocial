"use strict";
exports.id = 929;
exports.ids = [929];
exports.modules = {

/***/ 3128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Logo.ed71b5d1.png","height":225,"width":225,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAZlBMVEX////+/v79/f77/P73+P3s7/rg5vfW3vXV3fXQ2fTO1/TM1fPL1fPJ0/PH0vLDz/K3xvC1xO+vwO6nuu2BoOiAn+h6nOd4m+d2meZ0mOZpkuVokeVjjuVgjeRejORdi+Rci+RTh+M15++EAAAAQUlEQVR42h2LRxKAIBDAsthXFHuv//+kwiGZXIKAEGgT3KzAmsZHfhvo36ZeSsBtRXX+EY3dtWePAZ2sHTR8XvIBVS0CcyaJw88AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Logo2.98587b0f.png","height":756,"width":1440,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAZElEQVR42mNgLHBiK3BmyDQumFqXO7mGIcsEyAUKMggWujJkmVXNbt91Yv+O4/vKZrYA5YSAggJAnG1RMr3p2KVTRy6cKJhaz5BtBlLNAtSV78iQa9O3Ykb3sqkMOVZALkuBEwDj2yPbJY1sMwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ })

};
;