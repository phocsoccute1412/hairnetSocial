exports.id = 649;
exports.ids = [649];
exports.modules = {

/***/ 9140:
/***/ ((module) => {

// Exports
module.exports = {
	"frame": "menPage_frame__kIDuX",
	"titleMenPage": "menPage_titleMenPage__5yrNA",
	"framePart": "menPage_framePart__Yrwcu",
	"imagePart": "menPage_imagePart__Dw1mw",
	"blockInside": "menPage_blockInside__r_v2i",
	"titleBlock": "menPage_titleBlock__ClcWQ",
	"star": "menPage_star__2TWoD",
	"stargroup": "menPage_stargroup__jsfl_",
	"rowEach": "menPage_rowEach__7qMZ4",
	"rowEachFirst": "menPage_rowEachFirst__XcwJ_",
	"changeParent": "menPage_changeParent___h_Nk",
	"footer2": "menPage_footer2__Tyh70",
	"rankAndPrice": "menPage_rankAndPrice__ZhL0d",
	"PriceBlock": "menPage_PriceBlock__xjCDk",
	"noidung_dropdown": "menPage_noidung_dropdown__rcFtU",
	"dropdown": "menPage_dropdown__U5OOI",
	"active": "menPage_active__nzins",
	"buttonDropDown": "menPage_buttonDropDown__gyYhV",
	"dropdownSuggestButton": "menPage_dropdownSuggestButton__bLoUU",
	"noidung_dropdownSuggest": "menPage_noidung_dropdownSuggest__Ou77s",
	"activeSuggest": "menPage_activeSuggest__0hL7A",
	"linkProduct": "menPage_linkProduct__pjx_c",
	"searchinput": "menPage_searchinput__2VQLD",
	"labelsearch": "menPage_labelsearch__9RLXI",
	"wrapsearch": "menPage_wrapsearch__tn_iX"
};


/***/ }),

/***/ 8649:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProductBlock)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/images/publicPageImages/star.png
/* harmony default export */ const star = ({"src":"/_next/static/media/star.5f05cef8.png","height":119,"width":125,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAtUlEQVR42mPg5GCQFGcAgqJMxuJcRgYGBgkxBg42BhBgZgCB7cuYd28FSQhKM4BAoB+DgyeIce8w2/MnIAkjQUZ/NwaGGT1Mr++yfHnP+O0py/cXLG8usb2+wzJrMiMDENSkML28wPbzDfO3J6yf3jK2dzOAgJYGiLx8heH/e9b/31iOrwLZq6nCAAJRcQxfn7Es72TduoPhy1OWQFtGBgjoaGSc0c7EwAACc2cytFUzMjAwAADXEzUPVOYLKQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./src/styles/menPage.module.css
var menPage_module = __webpack_require__(9140);
var menPage_module_default = /*#__PURE__*/__webpack_require__.n(menPage_module);
;// CONCATENATED MODULE: ./src/pages/productPerformance/productBlock.tsx





function ProductBlock(props) {
    const imageUrl = `${props.url}${props.num}.jpg`;
    const arrayStar = [
        1,
        2,
        3,
        4,
        5
    ];
    const ranks = arrayStar.map((rank)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: star,
            alt: "picture",
            className: (menPage_module_default()).star
        }, rank);
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: `/productPagePersonal/${props.slug}`,
            className: (menPage_module_default()).linkProduct,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (menPage_module_default()).framePart,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: imageUrl,
                        alt: "picture",
                        className: (menPage_module_default()).imagePart,
                        width: 500,
                        height: 500,
                        priority: true
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (menPage_module_default()).blockInside,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: (menPage_module_default()).titleBlock,
                                children: "Title"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                id: "nameStore",
                                children: props.hairName
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (menPage_module_default()).rankAndPrice,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (menPage_module_default()).stargroup,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: ranks
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (menPage_module_default()).PriceBlock,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: (menPage_module_default()).Price,
                                        children: "Price:"
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            children: "100.000đ"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
} // ProductBlock.defaultProps = {
 //     framePart:'framePart',
 //     imageHair:'',
 //     imagePart:'imagePart',
 //     blockInside:'blockInside',
 //     titleBlock:'titleBlock',
 //     stargroup:'stargroup',
 //     star:'star'
 // }


/***/ })

};
;