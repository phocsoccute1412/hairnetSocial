exports.id = 24;
exports.ids = [24];
exports.modules = {

/***/ 3426:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_884a44', '__Inter_Fallback_884a44'","fontWeight":600,"fontStyle":"normal"},
	"className": "__className_884a44"
};


/***/ }),

/***/ 1024:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CarouselBanner)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\pages\\carousel.js","import":"Inter","arguments":[{"weight":"600","subsets":["latin"]}],"variableName":"inter"}
var target_path_src_pages_carousel_js_import_Inter_arguments_weight_600_subsets_latin_variableName_inter_ = __webpack_require__(3426);
var target_path_src_pages_carousel_js_import_Inter_arguments_weight_600_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_src_pages_carousel_js_import_Inter_arguments_weight_600_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./public/images/publicPageImages/Logo.png
var Logo = __webpack_require__(3128);
// EXTERNAL MODULE: ./public/images/publicPageImages/Logo2.png
var Logo2 = __webpack_require__(3781);
;// CONCATENATED MODULE: ./public/images/publicPageImages/reverseButtionCarousel.png
/* harmony default export */ const reverseButtionCarousel = ({"src":"/_next/static/media/reverseButtionCarousel.193daf9b.png","height":255,"width":197,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAAAAAD/rdHkAAAAPklEQVR42mP49vXrvwv3Gb58/3X46FeGX182Xfr7jeHl2md/vnxleLXuKZACCm6+CBT88v334cNfGcAa7gEAwHQrakMl8g4AAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/publicPageImages/slide2.jpg
/* harmony default export */ const slide2 = ({"src":"/_next/static/media/slide2.53147aca.jpg","height":1532,"width":2500,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQP/2gAMAwEAAhADEAAAALMFP//EABwQAAICAgMAAAAAAAAAAAAAAAIEAwUAERIzcv/aAAgBAQABPwCdBtm4Fte0YVE+yENEBcPWf//EABYRAAMAAAAAAAAAAAAAAAAAAAACMf/aAAgBAgEBPwBIf//EABgRAAIDAAAAAAAAAAAAAAAAAAACAyGB/9oACAEDAQE/AJKbD//Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/images/publicPageImages/buttonCarousel.png
/* harmony default export */ const buttonCarousel = ({"src":"/_next/static/media/buttonCarousel.284a1ff8.png","height":255,"width":197,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAAAAAD/rdHkAAAAMUlEQVR42mP4cvnb96/fGH48Of3921eGr7+fnvzxneHbl18vTn8DUc+BFEQQpgSiAQDesCyEZFjKIwAAAABJRU5ErkJggg==","blurWidth":6,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.min.css
var bootstrap_min = __webpack_require__(9090);
// EXTERNAL MODULE: ./src/styles/homePage.module.css
var homePage_module = __webpack_require__(9738);
var homePage_module_default = /*#__PURE__*/__webpack_require__.n(homePage_module);
;// CONCATENATED MODULE: ./src/pages/carousel.js












const picture = "../../public/images/publicPageImages/Logo2.png";
function CarouselBanner() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: `${(homePage_module_default()).titleBotHeader} ${(target_path_src_pages_carousel_js_import_Inter_arguments_weight_600_subsets_latin_variableName_inter_default()).className}`,
                children: "Your Choice - Prettier You Look"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (homePage_module_default()).khungCarousel,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (homePage_module_default()).containerSlider,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "radio",
                                className: (homePage_module_default()).CarouselIndicator,
                                id: (homePage_module_default()).Pic,
                                name: "Pic",
                                defaultChecked: true
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: slide2,
                                alt: "picture",
                                className: (homePage_module_default()).CarouselImage
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "radio",
                                className: (homePage_module_default()).CarouselIndicator,
                                id: (homePage_module_default()).Pic2,
                                name: "Pic"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: Logo2["default"],
                                alt: "picture",
                                className: (homePage_module_default()).CarouselImage
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "radio",
                                className: `${(homePage_module_default()).CarouselIndicator}`,
                                id: `${(homePage_module_default()).Pic3}`,
                                name: "Pic"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: Logo["default"],
                                alt: "picture",
                                className: (homePage_module_default()).CarouselImage
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (homePage_module_default()).buttonCarousel,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleOnClick,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: buttonCarousel,
                                alt: "picture",
                                className: (homePage_module_default()).nutphai
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (homePage_module_default()).buttonCarouselLeft,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleOnClickReverse,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: reverseButtionCarousel,
                                alt: "picture",
                                className: (homePage_module_default()).nuttrai
                            })
                        })
                    })
                ]
            })
        ]
    });
}
function handleOnClick() {
    const inputEles = document.querySelectorAll(`.${(homePage_module_default()).CarouselIndicator}`);
    console.log(inputEles);
    let flag = 0;
    for(let i = 0; i < inputEles.length; i++){
        if (inputEles[i].checked) {
            flag = i;
        }
    }
    if (flag === 2) flag = 0;
    else flag += 1;
    inputEles[flag].checked = true;
}
function handleOnClickReverse() {
    const inputElesReverse = document.querySelectorAll(`.${(homePage_module_default()).CarouselIndicator}`);
    let flag = 0;
    for(let i = 0; i < inputElesReverse.length; i++){
        if (inputElesReverse[i].checked) {
            flag = i;
        }
    }
    if (flag === 0) flag = 2;
    else flag -= 1;
    inputElesReverse[flag].checked = true;
}


/***/ }),

/***/ 9090:
/***/ (() => {



/***/ }),

/***/ 3559:
/***/ (() => {



/***/ })

};
;